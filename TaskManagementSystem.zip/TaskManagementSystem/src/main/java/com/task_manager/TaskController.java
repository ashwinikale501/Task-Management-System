package com.task_manager;

import java.nio.file.AccessDeniedException;

import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.config.Task;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/tasks")
public class TaskController {

	 @Autowired private TaskRepository taskRepo;
	    @Autowired private UserRepository userRepo;
	    @Autowired private JwtUtil jwtUtil;

	    private User getCurrentUser(HttpServletRequest request) {
	        String token = request.getHeader("Authorization").substring(7);
	        String username = jwtUtil.extractUsername(token);
	        return userRepo.findByUsername(username).orElseThrow();
	    }

	    @GetMapping
	    public List<Task> getAllTasks(HttpServletRequest request) {
	        return taskRepo.findByUser(getCurrentUser(request));
	    }

	    @PostMapping
	    public Task createTask(@RequestBody Task task, HttpServletRequest request) {
	        task.setUser(getCurrentUser(request));
	        return taskRepo.save(task);
	    }

	    @PutMapping("/{id}")
	    public Task updateTask(@PathVariable Long id, @RequestBody Task updatedTask, HttpServletRequest request) {
	        Task task = taskRepo.findById(id).orElseThrow();
	        if (!task.getUser().equals(getCurrentUser(request))) throw new AccessDeniedException("Unauthorized");
	        task.setTitle(updatedTask.getTitle());
	        task.setStatus(updatedTask.getStatus());
	        task.setDueDate(updatedTask.getDueDate());
	        task.setPriority(updatedTask.getPriority());
	        return taskRepo.save(task);
	    }

	    @DeleteMapping("/{id}")
	    public ResponseEntity<?> deleteTask(@PathVariable Long id, HttpServletRequest request) {
	        Task task = taskRepo.findById(id).orElseThrow();
	        if (!task.getUser().equals(getCurrentUser(request))) throw new AccessDeniedException("Unauthorized");
	        taskRepo.delete(task);
	        return ResponseEntity.ok("Task deleted.");
	    }
	}

	
	
	
	

