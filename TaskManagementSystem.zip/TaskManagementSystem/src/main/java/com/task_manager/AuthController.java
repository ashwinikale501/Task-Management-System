package com.task_manager;

import java.util.Collections;

import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
@RequestMapping("/auth")
public class AuthController {
	
	
	
	    @Autowired private AuthenticationManager authManager;
	    @Autowired private JwtUtil jwtUtil;
	    @Autowired private UserRepository userRepo;
	    @Autowired private PasswordEncoder encoder;

	    @PostMapping("/register")
	    public ResponseEntity<?> register(@RequestBody User user) {
	        user.setPassword(encoder.encode(user.getPassword()));
	        return ResponseEntity.ok(userRepo.save(user));
	    }

	    @PostMapping("/login")
	    public ResponseEntity<?> login(@RequestBody User user) {
	        authManager.authenticate(new UsernamePasswordAuthenticationToken(user.getUsername(), user.getPassword()));
	        String token = jwtUtil.generateToken(user.getUsername());
	        return ResponseEntity.ok(Collections.singletonMap("token", token));
	    }
	}



