package com.task_manager;

import java.time.LocalDate;

import org.apache.catalina.User;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Task {

 @Id @GeneratedValue
	    private Long id;

	    private String title;
	    private String description;
	    private String status; // Pending, In Progress, Completed
	    private LocalDate dueDate;
	    private String priority;

	    @ManyToOne
	    @JoinColumn(name = "user_id")
	    private User user;
	}

	
	

